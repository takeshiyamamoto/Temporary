This example bootstraps a default-probability curve over a number of
CDS and reprices them.
