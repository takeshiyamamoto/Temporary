This example shows how to set up a term structure and then price some
simple bonds. The last part is dedicated to peripherical computations
such as "Yield to Price" or "Price to Yield"
