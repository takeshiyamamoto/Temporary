This example prices a few bermudan swaptions using different short-rate
models calibrated to market swaptions.
