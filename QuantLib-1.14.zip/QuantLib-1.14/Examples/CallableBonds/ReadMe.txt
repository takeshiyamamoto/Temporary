This examples prices a number of callable bonds and compares the
results to known good data.
