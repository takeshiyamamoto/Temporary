This example uses the CompositeInstrument class to build a static
replication of a down-and-out barrier option.
