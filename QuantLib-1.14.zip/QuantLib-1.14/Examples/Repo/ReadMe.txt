Fixed-coupon bond repo valuation example.
