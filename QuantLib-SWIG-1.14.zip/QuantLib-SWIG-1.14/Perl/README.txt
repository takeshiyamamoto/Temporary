This is an experimental SWIG interface between perl and QuantLib. See
<joe@confucius.gnacademy.org> for more details.

Running 'make' in this directory will build the module; 'make install'
will make it available on your system.c

